//
//  ComposeViewController.swift
//  KYSMemo
//
//  Created by 경훈's MacBook on 2021/01/10.
//

import UIKit

class ComposeViewController: UIViewController {
    
    var editTarget: Memo?
    var orignalMemoContent: String?
    

    @IBAction func close(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }

    @IBOutlet weak var memoTextView: UITextView!
    @IBAction func save(_ sender: Any) {
        guard let memo = memoTextView.text, memo.count > 0 else{
            alert(message: "문장을 입력해주세요")
            return
    }
    if let target = editTarget {
        target.content = memo //편집한 내용 저장
        DataManager.shared.saveContext()
        NotificationCenter.default.post(name: ComposeViewController.MemoDidChange, object: nil)
            
        } else {
//            let newMemo = Memo(content : memo)
//            Memo.dummyMemoList.append(newMemo)
            DataManager.shared.addNewMemo(memo)
            // 새로운 memo instance 생성 & 배열에 저장
            NotificationCenter.default.post(name: ComposeViewController.newMemoDisInsert, object: nil)
        }
        dismiss(animated: true, completion: nil)
        
    }
    var willShowToken: NSObjectProtocol?
    var willHideToken: NSObjectProtocol?
    
    deinit {
        if let token = willShowToken{
            NotificationCenter.default.removeObserver(token)
        }
        
        if let token = willHideToken{
            NotificationCenter.default.removeObserver(token)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let memo = editTarget {
            navigationItem.title = "메모 편집"
            memoTextView.text = memo.content
            orignalMemoContent = memo.content
        } else {
            navigationItem.title = "새 메모"
            memoTextView.text = ""
        }
        
        memoTextView.delegate = self
        
        willShowToken = NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillShowNotification, object: nil, queue: OperationQueue.main, using: { [weak self] (noti) in
            guard let strongSelf = self else { return }
            
            if let frame = noti.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as?
                NSValue {
                let height = frame.cgRectValue.height
                
                var  inset = strongSelf.memoTextView.contentInset
                inset.bottom = height
                strongSelf.memoTextView.contentInset = inset
                
                inset = strongSelf.memoTextView.scrollIndicatorInsets
                inset.bottom = height
                strongSelf.memoTextView.scrollIndicatorInsets = inset
            }
        })
        
        
        willHideToken = NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillHideNotification, object: nil, queue: OperationQueue.main, using: { [weak self] (noti) in
                                                                guard let strongSelf = self else { return }
        
                                                                
                var inset = strongSelf.memoTextView.contentInset
                inset.bottom = 0
                strongSelf.memoTextView.contentInset = inset
                
                inset = strongSelf.memoTextView.scrollIndicatorInsets
                inset.bottom = 0
                strongSelf.memoTextView.scrollIndicatorInsets = inset
            
        })
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        memoTextView.becomeFirstResponder()
        navigationController?.presentationController?.delegate = self
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        memoTextView.resignFirstResponder()
        navigationController?.presentationController?.delegate = nil
    }
    
}



extension ComposeViewController: UITextViewDelegate {
   
    func textViewDidChange(_ textView: UITextView) { // text를 편집할 떄마다 반복적으로 호출
        if let original = orignalMemoContent, let edited = textView.text{
            isModalInPresentation = original != edited //modal 방식으로  동작할지 결정
        } else {
            
        }
    }
    
}
extension ComposeViewController: UIAdaptivePresentationControllerDelegate {
    func presentationControllerDidAttemptToDismiss(_ presentationController: UIPresentationController) {
        //original 과 edited 가 다를때 실행됨
        //편집 후 저장 안하고 취소할 건지 경고장 출력하기
        let alert = UIAlertController(title: "알림", message: "편집할 내용을 저장할까요?", preferredStyle: .alert)

        let okAction = UIAlertAction(title: "확인", style: .default) {
            [weak  self] (action) in self?.save(action)
        }
        alert.addAction(okAction)

        let cancelAction = UIAlertAction(title: "취소", style: .cancel) {
            [weak self] (action) in self?.close(action)
        }
        alert.addAction(cancelAction)

        
    
        present(alert, animated: true, completion: nil)
    
    }
    
}




extension ComposeViewController {
    //Notification name
    static let newMemoDisInsert = Notification.Name(rawValue: "newMemoDisInsert")
    static let MemoDidChange = Notification.Name(rawValue: "MemoDidChange")
}

