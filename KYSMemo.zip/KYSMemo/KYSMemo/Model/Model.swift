//
//  Model.swift
//  KYSMemo
//
//  Created by 경훈's MacBook on 2021/01/10.
//

import Foundation

//class Memo {
//    var content: String //새로운 메모
//    var insertDate: Date //메모 저장날짜
//    
//    init(content: String){ // constructor
//        self.content = content
//        insertDate = Date()
//    }
//    //table view에 메모를 표시하기 위한 dummy data
//    static var dummyMemoList = [
//        Memo(content: "Lorm Ipsum"),
//        Memo(content: "Dolar Amet")
//    ]
//}
